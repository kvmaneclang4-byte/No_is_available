LOGINMODULE - UNIT TESTS

Added JUnit 4 test classes:
- test/loginmodule/VerifyUserLoginTest.java
- test/loginmodule/PayrollCalculatorTest.java

The tests use the exact sample credentials in credentials.txt:
Administrator01,administrator
Student01,studentpassword

HOW TO RUN IN NETBEANS:
1. Extract this folder.
2. Open NetBeans and choose File > Open Project.
3. Select the LoginModule folder (the folder containing build.xml).
4. Make sure JUnit is available under Test Libraries.
5. Right-click the project and choose Test.

IMPORTANT:
VerifyUserLogin reads credentials.txt using a relative path. Run tests with the
project folder as the working directory (the normal NetBeans project setup).
The tests check valid and invalid login credentials, regular pay, overtime pay,
and total salary. Payroll expectations follow the supplied PayrollCalculator
implementation: overtime is paid at 1.5 times the hourly rate.
