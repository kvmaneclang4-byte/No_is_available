package loginmodule;

import org.junit.Test;
import static org.junit.Assert.*;

public class PayrollCalculatorTest {

    @Test
    public void testTotalSalaryWithRegularAndOvertimeHours() {
        PayrollCalculator calculator = new PayrollCalculator();

        double total = calculator.getTotalSalary(100.0, 40.0, 5.0);

        assertEquals(4750.0, total, 0.0001);
    }

    @Test
    public void testRegularPay() {
        PayrollCalculator calculator = new PayrollCalculator();

        calculator.getTotalSalary(100.0, 40.0, 5.0);

        assertEquals(4000.0, calculator.getRegularPay(), 0.0001);
    }

    @Test
    public void testOvertimePay() {
        PayrollCalculator calculator = new PayrollCalculator();

        calculator.getTotalSalary(100.0, 40.0, 5.0);

        assertEquals(750.0, calculator.getOverTimePay(), 0.0001);
    }

    @Test
    public void testSalaryWithoutOvertime() {
        PayrollCalculator calculator = new PayrollCalculator();

        double total = calculator.getTotalSalary(80.0, 35.0, 0.0);

        assertEquals(2800.0, total, 0.0001);
        assertEquals(2800.0, calculator.getRegularPay(), 0.0001);
        assertEquals(0.0, calculator.getOverTimePay(), 0.0001);
    }
}
