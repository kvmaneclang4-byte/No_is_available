package loginmodule;

import org.junit.Test;
import static org.junit.Assert.*;

public class VerifyUserLoginTest {

    @Test
    public void testValidAdministratorCredentials() {
        VerifyUserLogin login = new VerifyUserLogin();
        assertTrue(login.verifyUserLoginCredentials("Administrator01", "administrator"));
    }

    @Test
    public void testValidStudentCredentials() {
        VerifyUserLogin login = new VerifyUserLogin();
        assertTrue(login.verifyUserLoginCredentials("Student01", "studentpassword"));
    }

    @Test
    public void testInvalidPassword() {
        VerifyUserLogin login = new VerifyUserLogin();
        assertFalse(login.verifyUserLoginCredentials("Student01", "wrongpassword"));
    }

    @Test
    public void testUnknownUsername() {
        VerifyUserLogin login = new VerifyUserLogin();
        assertFalse(login.verifyUserLoginCredentials("UnknownUser", "studentpassword"));
    }
}
