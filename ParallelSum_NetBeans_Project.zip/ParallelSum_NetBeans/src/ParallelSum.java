import java.util.Scanner;

public class ParallelSum {

    // Calculates the sum from 1 to N using one thread.
    public static long sumSequential(long N) {
        long sum = 0;

        for (long i = 1; i <= N; i++) {
            sum += i;
        }

        return sum;
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter N: ");
        long N = input.nextLong();

        System.out.print("Enter number of threads: ");
        int numberOfThreads = input.nextInt();

        if (N < 1 || numberOfThreads < 1) {
            System.out.println("Invalid input! Enter positive numbers.");
            input.close();
            return;
        }

        // Sequential calculation
        long sequentialTotal = sumSequential(N);
        System.out.println("\nSequential Total: " + sequentialTotal);

        // Divide the range among the worker threads.
        SumWorker[] workers = new SumWorker[numberOfThreads];
        long baseSize = N / numberOfThreads;
        long remainder = N % numberOfThreads;
        long start = 1;

        for (int i = 0; i < numberOfThreads; i++) {
            long size = baseSize + (i < remainder ? 1 : 0);
            long end = start + size - 1;

            workers[i] = new SumWorker(start, end);
            workers[i].start();

            start = end + 1;
        }

        // Wait for every worker and combine its partial sum.
        long parallelTotal = 0;

        for (SumWorker worker : workers) {
            try {
                worker.join();
                parallelTotal += worker.getPartialSum();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                System.out.println("Calculation interrupted.");
                input.close();
                return;
            }
        }

        System.out.println("Parallel Total: " + parallelTotal);

        if (sequentialTotal == parallelTotal) {
            System.out.println("Verification: Totals match");
        } else {
            System.out.println("Verification: Totals do not match");
        }

        input.close();
    }
}

// Worker thread that calculates one part of the total.
class SumWorker extends Thread {
    private final long start;
    private final long end;
    private long partialSum;

    public SumWorker(long start, long end) {
        this.start = start;
        this.end = end;
        this.partialSum = 0;
    }

    @Override
    public void run() {
        for (long i = start; i <= end; i++) {
            partialSum += i;
        }
    }

    public long getPartialSum() {
        return partialSum;
    }
}
